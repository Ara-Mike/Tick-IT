package com.example.tick_it.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.tick_it.R;
import com.example.tick_it.models.Violation;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ViolationsAdapter extends RecyclerView.Adapter<ViolationsAdapter.ViolationViewHolder> {

    private List<Violation> violations;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());

    public ViolationsAdapter(List<Violation> violations) {
        this.violations = violations;
    }

    @NonNull
    @Override
    public ViolationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_violation, parent, false);
        return new ViolationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViolationViewHolder holder, int position) {
        Violation violation = violations.get(position);
        holder.bind(violation);
    }

    @Override
    public int getItemCount() {
        return violations.size();
    }

    public void updateData(List<Violation> newViolations) {
        this.violations = newViolations;
        notifyDataSetChanged();
    }

    class ViolationViewHolder extends RecyclerView.ViewHolder {
        private TextView tvViolationType, tvFineAmount, tvDescription;
        private TextView tvLicensePlate, tvLocation, tvIssueDate, tvStatus;

        public ViolationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvViolationType = itemView.findViewById(R.id.tvViolationType);
            tvFineAmount = itemView.findViewById(R.id.tvFineAmount);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvLicensePlate = itemView.findViewById(R.id.tvLicensePlate);
            tvLocation = itemView.findViewById(R.id.tvLocation);
            tvIssueDate = itemView.findViewById(R.id.tvIssueDate);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }

        public void bind(Violation violation) {
            tvViolationType.setText(violation.getViolationType());
            tvFineAmount.setText(String.format("$%.2f", violation.getFineAmount()));
            tvDescription.setText(violation.getDescription());
            tvLicensePlate.setText(violation.getLicensePlate());
            tvLocation.setText(violation.getLocation());

            if (violation.getIssueDate() != null) {
                tvIssueDate.setText(dateFormat.format(violation.getIssueDate()));
            }

            // Set status with appropriate background
            tvStatus.setText(violation.getStatus().toUpperCase());
            switch (violation.getStatus().toLowerCase()) {
                case "paid":
                    tvStatus.setBackgroundResource(R.drawable.status_paid_bg);
                    break;
                case "disputed":
                    tvStatus.setBackgroundResource(R.drawable.status_disputed_bg);
                    break;
                default:
                    tvStatus.setBackgroundResource(R.drawable.status_pending_bg);
                    break;
            }
        }
    }
}