package com.example.tick_it.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.example.tick_it.R;
import com.example.tick_it.utils.FirebaseUtil;

public class MotoristMainActivity extends AppCompatActivity {

    private Button btnViewViolations, btnPayFines, btnDisputeViolations, btnNotifications;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motorist_main);

        initializeViews();
        setupClickListeners();

        mAuth = FirebaseUtil.getAuth();
    }

    private void initializeViews() {
        btnViewViolations = findViewById(R.id.btnViewViolations);
        btnPayFines = findViewById(R.id.btnPayFines);
        btnDisputeViolations = findViewById(R.id.btnDisputeViolations);
        btnNotifications = findViewById(R.id.btnNotifications);
    }

    private void setupClickListeners() {
        btnViewViolations.setOnClickListener(v -> {
            startActivity(new Intent(MotoristMainActivity.this, ViolationsListActivity.class));
        });

        btnPayFines.setOnClickListener(v ->
                Toast.makeText(this, "Pay Fines - Feature coming soon", Toast.LENGTH_SHORT).show());

        btnDisputeViolations.setOnClickListener(v ->
                Toast.makeText(this, "Dispute Violations - Feature coming soon", Toast.LENGTH_SHORT).show());

        btnNotifications.setOnClickListener(v ->
                Toast.makeText(this, "Notifications - Feature coming soon", Toast.LENGTH_SHORT).show());
    }

    public void logout(android.view.View view) {
        mAuth.signOut();
        Intent intent = new Intent(MotoristMainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}