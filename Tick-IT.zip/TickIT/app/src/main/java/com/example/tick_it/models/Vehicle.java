package com.example.tick_it.models;

// Vehicle model
public class Vehicle {
    private String licensePlate;
    private String vehicleType;
    private String make;
    private String model;
    private int year;
    private boolean isPrimary;
}
