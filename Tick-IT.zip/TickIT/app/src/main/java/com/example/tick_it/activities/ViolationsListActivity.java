package com.example.tick_it.activities;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.example.tick_it.adapters.ViolationsAdapter;
import com.example.tick_it.models.Violation;
import com.example.tick_it.R;
import com.example.tick_it.utils.FirebaseUtil;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.List;

public class ViolationsListActivity extends AppCompatActivity {

    private RecyclerView rvViolations;
    private ProgressBar progressBar;
    private View emptyState;
    private TextView tvTotalViolations, tvPendingFines;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ImageButton btnBack;

    private ViolationsAdapter adapter;
    private List<Violation> violations = new ArrayList<>();
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private ListenerRegistration violationsListener;

    private static final String TAG = "ViolationsListActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_violations_list);

        Log.d(TAG, "=== ViolationsListActivity Started ===");

        initializeViews();
        setupRecyclerView();
        setupSwipeRefresh();
        setupBackButton();

        // Initialize Firebase
        mAuth = FirebaseUtil.getAuth();
        db = FirebaseUtil.getFirestore();

        if (mAuth.getCurrentUser() == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        setupRealTimeListener();
    }

    private void initializeViews() {
        rvViolations = findViewById(R.id.rvViolations);
        progressBar = findViewById(R.id.progressBar);
        emptyState = findViewById(R.id.emptyState);
        tvTotalViolations = findViewById(R.id.tvTotalViolations);
        tvPendingFines = findViewById(R.id.tvPendingFines);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        btnBack = findViewById(R.id.btnBack);

        tvTotalViolations.setText("0");
        tvPendingFines.setText("$0.00");
    }

    private void setupRecyclerView() {
        adapter = new ViolationsAdapter(violations);
        rvViolations.setLayoutManager(new LinearLayoutManager(this));
        rvViolations.setAdapter(adapter);
    }

    private void setupSwipeRefresh() {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Log.d(TAG, "Pull to refresh triggered");
                loadViolations();
            }
        });
    }

    private void setupBackButton() {
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void setupRealTimeListener() {
        Log.d(TAG, "Setting up real-time Firestore listener");
        showLoading(true);

        String currentUserId = mAuth.getCurrentUser().getUid();
        Log.d(TAG, "Listening for violations for user: " + currentUserId);

        violationsListener = db.collection("violations")
                .whereEqualTo("userId", currentUserId)
                .orderBy("issueDate", Query.Direction.DESCENDING)
                .addSnapshotListener((querySnapshot, error) -> {
                    showLoading(false);
                    swipeRefreshLayout.setRefreshing(false);

                    if (error != null) {
                        Log.e(TAG, "Firestore error: " + error.getMessage(), error);
                        Toast.makeText(ViolationsListActivity.this,
                                "Connection error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        showEmptyState();
                        return;
                    }

                    if (querySnapshot != null && !querySnapshot.isEmpty()) {
                        processViolationsSnapshot(querySnapshot.getDocuments());
                    } else {
                        Log.d(TAG, "No violations found for user");
                        violations.clear();
                        updateUI(0, 0.0);
                        showEmptyState();
                    }
                });
    }

    private void processViolationsSnapshot(List<DocumentSnapshot> documents) {
        violations.clear();
        double totalPendingFines = 0;

        Log.d(TAG, "Processing " + documents.size() + " violations");

        for (DocumentSnapshot document : documents) {
            try {
                Violation violation = document.toObject(Violation.class);
                if (violation != null) {
                    violation.setId(document.getId());
                    violations.add(violation);

                    if ("pending".equals(violation.getStatus())) {
                        totalPendingFines += violation.getFineAmount();
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error processing violation: " + e.getMessage(), e);
            }
        }

        updateUI(violations.size(), totalPendingFines);
        adapter.updateData(violations);

        Log.d(TAG, "Updated UI with " + violations.size() + " violations");
    }

    private void loadViolations() {
        // Manual refresh - real-time listener will handle updates
        showLoading(true);
    }

    private void updateUI(int totalViolations, double totalPendingFines) {
        tvTotalViolations.setText(String.valueOf(totalViolations));
        tvPendingFines.setText(String.format("$%.2f", totalPendingFines));

        if (totalViolations == 0) {
            showEmptyState();
        } else {
            hideEmptyState();
        }
    }

    private void showLoading(boolean show) {
        if (show) {
            progressBar.setVisibility(View.VISIBLE);
            rvViolations.setVisibility(View.GONE);
            emptyState.setVisibility(View.GONE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    private void showEmptyState() {
        emptyState.setVisibility(View.VISIBLE);
        rvViolations.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);
    }

    private void hideEmptyState() {
        emptyState.setVisibility(View.GONE);
        rvViolations.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.GONE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (violationsListener != null) {
            violationsListener.remove();
        }
    }
}