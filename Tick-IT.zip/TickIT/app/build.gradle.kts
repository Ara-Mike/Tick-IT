plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.example.tick_it"
    compileSdk = 33  // Use 33 for maximum compatibility

    defaultConfig {
        applicationId = "com.example.tick_it"
        minSdk = 21
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

configurations.all {
    // Force consistent Kotlin versions and resolve conflicts
    resolutionStrategy {
        force(
            "org.jetbrains.kotlin:kotlin-stdlib:1.8.10",
            "org.jetbrains.kotlin:kotlin-stdlib-common:1.8.10",
            "org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.8.10",
            "org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.8.10"
        )

        // Remove duplicate dependencies
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib-jdk7")
        exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib-jdk8")
    }
}

dependencies {
    // Use stable, compatible versions
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")

    // Explicit Kotlin dependency to force version
    implementation("org.jetbrains.kotlin:kotlin-stdlib:1.8.10")

    // Firebase with compatible BOM
    implementation(platform("com.google.firebase:firebase-bom:32.7.3"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")

    // Compatible activity version
    implementation("androidx.activity:activity:1.6.1")
    implementation(libs.swiperefreshlayout)
}